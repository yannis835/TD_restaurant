package com.example.td1.network

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NetworkConstants {
    companion object {
        val url = "http://test.api.catering.bluecodegames.com/menu"
        val idShopKey = "id_shop"
    }
}